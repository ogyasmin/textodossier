package com.tod.android;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import com.tod.android.adapter.SubActionsAdapter;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SubActionsFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SubActionsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SubActionsFragment extends Fragment implements SubActionsAdapter.SubActionsAdapterListener {

    private static final String ARG_PARAM_ACTIONS = "com.tod.args.actions";
    private static String[] mActions;
    private int mMasterId;
    private SubActionsAdapter mSubActionsAdapter;
    private ArrayList<Integer> mSelections;
    @Bind(R.id.actions_list) protected ListView mActionsList;
    @Bind(R.id.button) protected Button mButton;
    private OnFragmentInteractionListener mListener;

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *

     * @return A new instance of fragment ActionsFragment.
     */
    public static SubActionsFragment newInstance(String[] actions) {
        SubActionsFragment fragment = new SubActionsFragment();
        Bundle args = new Bundle();
        args.putStringArray(ARG_PARAM_ACTIONS, actions);
        fragment.setArguments(args);
        return fragment;
    }

    public SubActionsFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mActions = getArguments().getStringArray(ARG_PARAM_ACTIONS);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_sub_actions, container, false);
        ButterKnife.bind(this, view);
        mSelections = new ArrayList<>();
        mSubActionsAdapter =  new SubActionsAdapter(mActions);
        mSubActionsAdapter.setSelectionListener(this);
        mActionsList.setAdapter(mSubActionsAdapter);
        // Inflate the layout for this fragment
        return view;

    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mListener = (OnFragmentInteractionListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @OnClick(R.id.button)
    public void onButtonClicked(){
        if(mListener!=null){
            mListener.subActionSelect(mSelections,mMasterId);
        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void setMasterId(int id) {
        this.mMasterId = id;
    }

    @Override
    public void subActionSelect(int index, boolean checked) {
        if(checked){
            if(!mSelections.contains(index)){
                mSelections.add(index);
            }
        }
        else{
            mSelections.remove(index);
        }
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        void subActionSelect(ArrayList<Integer>  selections, int masterId);
    }
}
