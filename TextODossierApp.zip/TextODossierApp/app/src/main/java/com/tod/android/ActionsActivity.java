package com.tod.android;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

public class ActionsActivity extends AppCompatActivity implements ActionsFragment.OnFragmentInteractionListener,SubActionsFragment.OnFragmentInteractionListener {
    private final static String TAG =ActionsActivity.class.getSimpleName();
    @Bind(R.id.user_name) protected TextView mUserName;
    @Bind(R.id.user_title) protected TextView mUserTitle;
    private static String[] DOCTOR_ACTIONS ={"Nouvelle ordonnance", "Signes vitaux","Evaluations"};
    private static String[] DOCTOR_ACTIONS_CODE ={"NO", "SV","EV"};
    private static String[] ORDONNANCE_SUB_ACTIONS ={"Antihypertenseur", "Per OS"};
    private static String[] ORDONNANCE_SUB_ACTIONS_CODE ={"ATHT", "PO"};
    private static String[] SV_SUB_ACTION ={"Sub SV Test1", "SV 2","SubTest3"};
    private static String FREQUENCE_PRESC = "-die";
    ProgressDialog mProgress ;
    private ActionsFragment mActionsFragment;
    private SubActionsFragment mSubActionsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actions);
        ButterKnife.bind(this);
        mProgress = new ProgressDialog(this);

        TodGlobals.initPreferences(this);

        mUserName.setText(TodGlobals.getUserName(this));
        mUserTitle.setText(TodGlobals.getUserTitle(this));
        mActionsFragment = ActionsFragment.newInstance(DOCTOR_ACTIONS);
        attachFragment(mActionsFragment);
    }

    private void attachFragment(Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.selection_fragment,fragment);
        fragmentTransaction.commit();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_actions, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void select(int id) {
        switch (id){
            case 0:{
                mSubActionsFragment =  SubActionsFragment.newInstance(ORDONNANCE_SUB_ACTIONS);
                mSubActionsFragment.setMasterId(id);
                attachFragment(mSubActionsFragment);
                break;
            }
            case 1:{
                mSubActionsFragment =  SubActionsFragment.newInstance(SV_SUB_ACTION);
                mSubActionsFragment.setMasterId(id);
                attachFragment(mSubActionsFragment);
                break;
            }
            case 2:{
                TodGlobals.sendSMS(this, DOCTOR_ACTIONS[id]);
                break;
            }
        }
    }
    @Override
    public void subActionSelect(ArrayList<Integer> selections, int masterId) {
        String message = "J0N1P0,5555-3";
        switch (masterId){
            case 0:{
                if(selections !=null && selections.size()>0){
                    for (int i = 0; i < selections.size(); i++) {
                        message= message + "," + DOCTOR_ACTIONS_CODE[masterId] + "-" + ORDONNANCE_SUB_ACTIONS_CODE[i]+ FREQUENCE_PRESC;
                    }
                }
                break;
            }
            case 1:{
                if(selections !=null && selections.size()>0){
                    for (int i = 0; i < selections.size(); i++) {
                        message= message + "," + DOCTOR_ACTIONS_CODE[masterId] + "-" + ORDONNANCE_SUB_ACTIONS_CODE[i]+ FREQUENCE_PRESC;
                    }
                }
                break;
            }
            case 2:{
                message = message + "," + DOCTOR_ACTIONS_CODE[masterId]+ FREQUENCE_PRESC;
                break;
            }
        }
        //TodGlobals.sendSMS(this, message);
        Toast.makeText(this,message,Toast.LENGTH_LONG ).show();
    }
}
